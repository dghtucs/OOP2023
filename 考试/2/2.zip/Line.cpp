#include"Line.h"
template<typename T>
bool Line<T>::intersect(const Line& l)
{
    if((l.k==k&&l.b==b)||l.k != k)
        return false;
    else
        return true;
}


template<typename T>
void Line<T>::show()
{
    std::cout << k << ',' << b << endl;
}
