#pragma once

template<typename T>
class Line
{
private:
    /* data */
    
public:
    T k,T b;
    Line(T k_,T b_ = 0){k = k_;b = b_;}
    ~Line();
    bool intersect(const Line&);
    void show();
    bool operator<(Line& p)     
	{
		if(k < p.k)
            return true;
        else 
            return false;
	}
};


