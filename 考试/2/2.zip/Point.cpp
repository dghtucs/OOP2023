#include"Point.h"

template<typename T>
void Point<T>::move(T dx, T dy)
{
    x+=dx;
    y+=dy;
}
template<typename T>
void Point<T>::show()
{
    std::cout << '(' << x << ',' << y << ')' << endl;
}
template<typename T>
bool Point<T>::check(Line<T> const& l){
    if((l.k*x+l.b)==y)
        return true;
    else 
        return false;
}