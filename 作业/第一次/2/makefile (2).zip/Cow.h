#pragma once
#include<string>
using namespace std;

class Cow
{
public:
    /* data */
    string name_;
    double l_,u_,m_,leftFood_;
    Cow(string n,double l,double u,double m);
    ~Cow();
};














