#include"Cow.h"



Cow::Cow(string n,double l,double u,double m)
{
    name_ = n;
    l_ = l;
    u_ = u;
    m_ = m;
    leftFood_ = 0;
}



Cow::~Cow()
{
}











