#include "Matrix.h"
#include <iostream>
using namespace std;

Matrix::Matrix()
{
    col = 0;
    row = 0;
}
Matrix::Matrix(int _row, int _col)
{
    col = _col;
    row = _row;
    elem = new int *[row];
    for (int i = 0; i < col; i++)
        elem[i] = new int[col];
}
Matrix::~Matrix() {}

Matrix Matrix::operator+(const Matrix &a)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            this->elem[i][j] += a.elem[i][j];
        }
    }
    return *this;
}
Matrix Matrix::operator-(const Matrix &a)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            this->elem[i][j] -= a.elem[i][j];
        }
    }
    return *this;
}
Matrix Matrix::operator*(const int a)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            this->elem[i][j] *= a;
        }
    }
    return *this;
}
Matrix Matrix::operator*(const Matrix &a)
{
    Matrix m(a.row, a.col);
    for (int i = 0; i < row; i++)
    {

        for (int j = 0; j < col; j++)
        {
            int tem = 0;
            for (int k = 0; k < col; k++)
            {
                tem += this->elem[i][k++] * a.elem[k++][j];
            }
            m.elem[i][j] = tem;
        }
    }
    return m;
}
Matrix transpose(const Matrix &a)
{
    int col = a.row;
    int row = a.col;
    int **e = new int *[row];
    for (int i = 0; i < col; i++)
        e[i] = new int[col];
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            e[i][j] = a[j][i];
        }
    }
    Matrix m(row, col);
    m.elem = e;
    return m;
}
int *Matrix::operator[](int a) const
{
    return this->elem[a];
}
ostream &operator<<(ostream &os, const Matrix &a)
{
    int col = a.col;
    int row = a.row;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            os << a.elem[i][j];
            if (j != col - 1)
                os << " ";
        }
        os << endl;
    }
    return os;
}
istream &operator>>(istream &is, Matrix &a)
{
    int col = a.col;
    int row = a.row;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            is >> a.elem[i][j];
        }
    }
    return is;
}
