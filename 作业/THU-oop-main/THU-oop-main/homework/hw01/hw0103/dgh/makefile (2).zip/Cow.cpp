#include"Cow.h"


Cow::Cow(std::string n,double l,double u,double m)
{
    name = n;
    l = l;
    u = u;
    m = m;

}


















