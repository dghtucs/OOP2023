#include"Vehicle.h"


Vehicle::Vehicle(int num, string engine) : engine_(engine),wheel_(num)
{
    cout << "Finish building a vehicle with " \
    << this->wheel_.get_num() << " wheels and a " << this->engine_.get_name() << " engine." << endl;
}


void Vehicle::describe()
{
    cout << "A vehicle with " << this->wheel_.get_num() \
    << " wheels and a " << this->engine_.get_name() << " engine." << endl;
}
Vehicle::~Vehicle()
{

}