#include"altset.h"

Altset& Altset::operator = (const Altset &altset)
{
    data_ = altset.data_;
    len_ = altset.len_;
    return *this;
}


Altset& Altset::operator = (Altset &&altset)
{
    data_ = altset.data_;
    len_ = altset.len_;
    return *this;
}

void Altset::inverse(int index)
{
    if(index >= len_)return;
    if(data_[index] == '0')
        data_[index] = '1';
    else
        data_[index] = '0';
}

void Altset::append(int value)
{
    if(value == 1)
        data_ = "1"+data_;
    else
        data_ = "0"+data_;
    len_++;
}

bool Altset::get(int index) const
{
    if(data_[index] == '1')
        return true;
    else
        return false;
}
bool Altset::empty() const
{
    if(data_ == "" || len_ == 0)
        return true;
    return false;
}

int Altset::count() const
{
    int count = 0;
    for(int i = 0;i < len_;i++)
    {
        if(data_[i] == '1')
            count++;

    }
    return count;
}







