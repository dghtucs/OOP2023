#pragma once
#include<string>
using namespace std;

class Altset {
    string data_;
    int len_;

public:
    Altset()=default;
    ~Altset()=default;

    Altset(const char *data, int len):data_(data),len_(len){}
	Altset& operator = (const Altset &altset);
    Altset& operator = (Altset &&altset);

    void inverse(int index);
    void append(int value);
    bool get(int index) const;
    bool empty() const;
    int count() const;
};
